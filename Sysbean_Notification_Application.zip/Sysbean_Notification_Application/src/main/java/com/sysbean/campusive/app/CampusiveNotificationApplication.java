package com.sysbean.campusive.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CampusiveNotificationApplication {

	public static void main(String[] args) {
		SpringApplication.run(CampusiveNotificationApplication.class, args);
	}

}
