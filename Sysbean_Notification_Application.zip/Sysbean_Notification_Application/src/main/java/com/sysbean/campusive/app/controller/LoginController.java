package com.sysbean.campusive.app.controller;

import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.sysbean.campusive.app.config.DomainUser;
import com.sysbean.campusive.app.dto.*;
import com.sysbean.campusive.app.service.UserService;

@Controller
public class LoginController {

    private final UserService userService;

    public LoginController(UserService userService) {
        this.userService = userService;
    }

    @GetMapping("/login")
    public String getLogin(){
        return "login";
    }

    @GetMapping("/")
    public String getIndex() {
        return "redirect:/app/";
    }


    @GetMapping("/reset/password")
    public ModelAndView resetPassword() {
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.addObject("changePassword", new ChangePasswordDTO());
        //System.out.println(passwords);
        modelAndView.setViewName("reset-password");
        return modelAndView;
    }

    //    @PostMapping("/resetPassword")
//	public ModelAndView updatePassword(@ModelAttribute("passwords") CreatePasswordDTO createPasswordDTO) {
//    	ModelAndView modelAndView = new ModelAndView();
//		CreatePasswordDTO ressetPassword = resetPasswordService.ressetPassword(createPasswordDTO);
//        //modelAndView.setViewName(createPasswordDTO.getPassword());
//        System.out.println(ressetPassword+"satyaprakash swain");
//		modelAndView.setViewName("redirect:/login");
//		return modelAndView;
//    }
    @RequestMapping(value = "/resetPassword", method = RequestMethod.POST)
    public ModelAndView changePassword(@ModelAttribute("changePassword") ChangePasswordDTO changePassword, @AuthenticationPrincipal DomainUser domainUser) {
        ModelAndView modelAndView = new ModelAndView();

        boolean passwordChanged = userService.changePassword(changePassword, domainUser);
        if(passwordChanged) {
            modelAndView.addObject("changePassword", new ChangePasswordDTO());
            modelAndView.addObject("message", "Password changed");
        } else {
            changePassword.setConfirmPassword("");
            modelAndView.addObject("changePassword", changePassword);
            modelAndView.addObject("message", "Failed to change the password");
        }

        modelAndView.setViewName("redirect:/login");
        return modelAndView;
    }
}



