package com.sysbean.campusive.app.model;

public enum NotificationType {
    GENERAL,
    HOLIDAY,
    EXAM_DATE,
    SCHOOL_TIMING,
    FEE_REMINDER,
    DISCIPLINARY_ACTION,
}